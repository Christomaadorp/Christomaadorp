<?php

return [
    'site_title' => 'nCloud DTE',

];
